#Lambda = 1.0 / desired mean
import xml.etree.cElementTree as ET
import random
from random import randint

def main():
 
    # mean for poison random variable
    lambd0 = 2
    lambd1 = 2
    # lambd1 = input("Mean of lane 1 : ")
    # lambd0 = input("Mean of lane 0: ")

    time_gap_between_instances = 400
    
    num = 150
    # num = input("Number of vehicles in one lane : ")

    print("Parameters:")
    print("mean lane0:"+str(lambd0))
    print("mean lane1:"+str(lambd1))

    print("Start Generating:")


    # departure_time, departure_lane, vehicle_ID
    vip_departure_time = random.uniform(max(lambd1,lambd0)*num/4,max(lambd1,lambd0)*num/2)
    departure_time_lane1 = random.expovariate(1.0/lambd1)
    departure_time_lane0 = random.expovariate(1.0/lambd0)

    print(vip_departure_time)
    vehicles_in_lane0 = 0
    vehicles_in_lane1 = 0

    vehicle_list = []
    has_ev_left = False
    while(True):
        if (vip_departure_time < departure_time_lane0 or vip_departure_time < departure_time_lane1):
            if not has_ev_left:
                print("VIP depart: " + str(vip_departure_time))
                vehicle_list.append([str(vip_departure_time),"0","vip"])
                if (vip_departure_time > departure_time_lane0):
                    departure_time_lane0 = vip_departure_time + random.expovariate(1.0/lambd0)

                if vip_departure_time > departure_time_lane1:
                    departure_time_lane1 = vip_departure_time + random.expovariate(1.0/lambd1)
                has_ev_left = True
                pass


        
        if departure_time_lane0 < departure_time_lane1 and vehicles_in_lane0 < num:
            

            vehicle_list.append([str(departure_time_lane0),"0","v"+str(vehicles_in_lane0+vehicles_in_lane1)])
            departure_time_lane0 = departure_time_lane0 + random.expovariate(1.0/lambd0)
            vehicles_in_lane0 = vehicles_in_lane0 +1

        elif vehicles_in_lane1 <= num:
            vehicle_list.append([str(departure_time_lane1),"1","v"+str(vehicles_in_lane0+vehicles_in_lane1)])
            departure_time_lane1 = departure_time_lane1 + random.expovariate(1.0/lambd1)
            vehicles_in_lane1 = vehicles_in_lane1 +1

        else:
            break
    
      #add DOM elements
    root = ET.Element("routes")
    ET.SubElement(root, "vType", color="green", tau="0", accel="2.9", decel="7.5", id="Car", length="4.3", maxSpeed="28", sigma="0.0", minGap="-1").text = ""        #for normal vehicles
    ET.SubElement(root, "vType", color="red",tau="0", accel="2.9", decel="7.5", id="CarVIP", length="6.5", maxSpeed="28", sigma="0.0", minGap="-1").text = ""    #for VIP
    ET.SubElement(root, "route", id="route0", edges="1to2").text = ""

    for vehicle in vehicle_list:
        print(vehicle)
        if vehicle[2] != "vip":
            v_type = "Car"
            ET.SubElement(root, "vehicle",  depart=vehicle[0], departLane=vehicle[1], arrivalLane=vehicle[1], id=vehicle[2], route="route0", type=v_type).text = ""
        elif vehicle[2] == "vip":
            v_color = "red"
            v_type = "CarVIP"
            ET.SubElement(root, "vehicle",  depart=vehicle[0], departLane=vehicle[1], id=vehicle[2], route="route0", type=v_type).text = ""

    
    tree = ET.ElementTree(root)
    tree.write("hello.rou.xml")
 
if __name__ == '__main__':
    main()

#<routes>
#<vType tau="0" accel="1.0" decel="2.0" id="Car" length="2.0" maxSpeed="10.0" sigma="0.0" minGap="-1"/>
#<vType tau="0" accel="10.0" decel="10.0" id="Car1" length="2.0" maxSpeed="180.0" sigma="0.0" minGap="-1"/>
#<route id="route0" edges="1to2"/>
#<flow id="1" begin="0" end="50" depart="0" type="Car" period="2.5" departLane="1" arrivalLane="1" route="route0"/>
#<flow id="2" begin="4" end="54" depart="0" type="Car" period="2.5" departLane="0" arrivalLane="0" route="route0"/>
#<vehicle color="red" depart="55" departLane="1" arrivalLane="1" id="vip" route="route0" type="Car1"/>
#</routes>
